Files for the repository, ***not*** the editor.
