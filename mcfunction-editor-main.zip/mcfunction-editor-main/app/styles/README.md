# Styles
In this folder, the stylesheets are here.
### Why is 'light.qss' so much smaller than 'dark.qss'
Most native operating systems default light theme, no changes are needed and it looks automatically native.
