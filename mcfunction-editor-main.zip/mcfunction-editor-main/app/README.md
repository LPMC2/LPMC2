# App
This is where the actual code is.<br>
Feel free to go in any folders, they'll also have a description.<br>
Make sure to read CONTRIBUTING.md if you came into this directory for contributing.
